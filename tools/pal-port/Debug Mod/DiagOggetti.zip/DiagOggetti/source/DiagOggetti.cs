// SPDX-License-Identifier: GPL-3.0-or-later
//
// Oggetti lontani (prova) - mod di debug per MediEvilRecomp ITA
// Copyright (C) 2026
// Author: https://github.com/Leproide
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// Prova della correzione degli oggetti che compaiono da vicino (es. i battenti del cancello
// del cimitero).
//
// Cosa fa il gioco (func_80041B84, una volta per frame) sugli oggetti della zona intorno a Dan
// (lista a 0x800EEA50, collegata a +0x4): distanza al quadrato da un punto di riferimento
// (0x800EEB80) meno un margine del tipo (tipo +0x8 -> +0x54), confrontata con due soglie al
// quadrato (puntatore a 0x800EEB94): [0] sveglia, [4] disattivazione (al cimitero 2500 e 3500).
//  - entro la sveglia l'oggetto e' attivo e si disegna normalmente;
//  - tra sveglia e disattivazione dorme (flag 0x20000000 in +0x50): il gioco lo sostituisce
//    con un elemento di disegno fermo (+0x70 -> [0]) marcato nascosto (flag 0x40 in +0xA);
//  - oltre la disattivazione esce dalla lista.
// Dal log 0.5: da sveglio +0x70 -> [0] e' vuoto, da addormentato c'e' ed e' sempre nascosto.
//
// 0.6:
//  - durante il controllo del gioco la soglia di disattivazione viene alzata (x Draw distance,
//    al massimo x2) e poi rimessa com'era: gli oggetti restano addormentati, e nella lista,
//    piu' lontano. La sveglia non cambia: IA, eventi e trappole partono come nell'originale;
//  - gli oggetti addormentati entro quella distanza hanno il loro elemento fermo reso visibile
//    (solo il flag 0x40). Da lontano restano quindi fermi nell'ultima posa.
// 0.7: le fiaccole addormentate perdevano la fiamma (la fa l'oggetto mentre e' sveglio).
// 0.8: il contatore +0x35 della 0.7 non bastava (il gioco le riaddormentava nello stesso
// frame). Ora per i tipi delle fiaccole e luci (oggetti con flag 0x80 in +0x4C) si alza il
// margine di distanza del tipo (+0x54, sottratto dalla distanza): il gioco stesso le considera
// vicine e le tiene sveglie fino alla distanza allargata, con fiamma e luce. Solo quei tipi:
// nemici e trappole restano con la sveglia originale. I margini originali vengono rimessi
// quando la mod si spegne o cambiano le soglie (livello).
// Distanza allargata: soglia di disattivazione x Draw distance, al massimo x3.
// 0.9: il margine della 0.8 non sveglia le fiaccole (il gioco non le sveglia per distanza
// oltre un certo stato) e ha preso anche un tipo sconosciuto: tolto. Ora:
//  - fiaccole e luci (flag 0x80 in +0x4C) addormentate NON vengono ridisegnate: da lontano
//    spariscono come nel gioco originale invece di restare spente;
//  - precaricamento: un oggetto addormentato che non e' mai stato sveglio non ha ancora il
//    suo elemento fermo (+0x70 -> [0] vuoto) e quindi non si puo' disegnare (il cancello
//    alla prima visita). Per questi, solo se hanno il contenitore +0x70 (i nemici non lo
//    hanno), una volta sola il contatore +0x35 viene messo a 1: il gioco li sveglia per un
//    frame e al frame dopo, riaddormentandoli, crea l'elemento fermo. Righe "precarico".
// 0.10: il precaricamento funziona, ma il cancello alla prima visita non c'e' ancora: scrive
// quando un oggetto entra ("entra") o esce ("esce") dalla lista, con tipo, distanza e
// posizione, per vedere a che distanza il gioco ci mette il cancello.
// 0.11: dal log 0.10 gli oggetti entrano nella lista quasi tutti a ~2500: li crea il
// "caricatore" del gioco (func_8004218C), che quando il punto di riferimento cambia cella
// scorre le celle vicine e crea gli oggetti piu' vicini della soglia di SVEGLIA ([0]).
// Raggio di caricamento: solo durante quella funzione la soglia [0] viene alzata alla
// distanza allargata e poi rimessa. Gli oggetti vengono quindi creati prima (addormentati,
// fuori dalla sveglia vera), il precaricamento crea il loro elemento fermo e vengono
// disegnati. La sveglia (IA, eventi) resta quella originale.
// Si accende e spegne da Mods -> Oggetti lontani. Con MEDIEVIL_DEBUG scrive nel log
// ("[DiagOggetti]") le soglie, un riepilogo ogni ~2 secondi e gli oggetti mostrati/nascosti.

using System;
using System.Collections.Generic;
using ImGuiNET;
using RecompOne.Runtime.Context;
using RecompOne.Runtime.Memory;
using RecompOne.Runtime.Modding;

public class DiagOggettiMod : IMod
{
    const string SettingKey = "mods.diag-oggetti.attivo";
    const float MaxFactor = 3f;             // disattivazione al massimo triplicata

    const uint ThingList = 0x800EEA50u;     // sentinella della lista degli oggetti
    const uint RefPoint = 0x800EEB80u;      // punto di riferimento (x, y, z)
    const uint RangePtr = 0x800EEB94u;      // -> [0] soglia sveglia^2, [4] soglia disattivazione^2

    const uint ThingNext = 0x04u;
    const uint ThingType = 0x08u;
    const uint ThingFlags = 0x50u;
    const uint ThingPos = 0x24u;
    const uint ThingItems = 0x70u;
    const uint TypeRadius = 0x54u;
    const uint ItemFlags = 0x0Au;
    const uint FlagAsleep = 0x20000000u;
    const uint ThingKind = 0x4Cu;
    const uint KindLight = 0x00000080u;     // fiaccole, bracieri (dal log)
    const uint ThingWakeCounter = 0x35u;
    static readonly HashSet<uint> _preloaded = new();
    static HashSet<uint> _inList = new(), _inListNow = new();
    const ushort FlagHidden = 0x0040;

    public static bool Enabled = true;

    static readonly bool DiagOn = !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("MEDIEVIL_DEBUG"));
    static readonly HashSet<uint> _shown = new();
    static readonly HashSet<uint> _kept = new();
    static int _lines;
    static long _calls;
    static uint _range, _origFar, _origWake;
    static bool _patched;
    static string _info = "";

    static void Log(string s)
    {
        if (DiagOn && _lines++ < 20000) Console.WriteLine("[DiagOggetti] " + s);
    }

    public void OnLoad()
    {
        Enabled = RecompOne.Runtime.Config.Settings.Get<string>(SettingKey, "1") != "0";
    }

    public void OnUnload()
    {
        _shown.Clear();
        _kept.Clear();
        _preloaded.Clear();
    }

    public void DrawSettings()
    {
        if (ImGui.Checkbox("Disegna gli oggetti lontani (porte, cancelli)", ref Enabled))
            RecompOne.Runtime.Config.Settings.Set(SettingKey, Enabled ? "1" : "0");
        ImGui.TextDisabled(_info);
    }

    static float Factor()
    {
        float s = RecompOne.Runtime.Config.Settings.Get<float>("render.draw_distance", 1f);
        return Math.Clamp(s, 1f, MaxFactor);
    }

    // raggio di caricamento: soglia di sveglia allargata solo mentre il gioco crea gli oggetti
    static uint _loaderSaved;
    static bool _loaderPatched;

    [PreHook("game", Address = 0x8004218Cu)]
    public static void BeforeLoader(CpuContext c, IMemory m)
    {
        _loaderPatched = false;
        uint range = m.ReadU32(RangePtr);
        if (!Ram(range) || !Enabled || range != _range) return;
        float f = Factor();
        if (f <= 1f) return;
        double loader = Math.Sqrt(_origFar) * f;
        _loaderSaved = m.ReadU32(range);
        m.WriteU32(range, (uint)Math.Min(loader * loader, uint.MaxValue));
        _loaderPatched = true;
        Log($"caricatore: raggio {loader:0} (sveglia {Math.Sqrt(_loaderSaved):0})");
    }

    [PostHook("game", Address = 0x8004218Cu)]
    public static void AfterLoader(CpuContext c, IMemory m)
    {
        if (!_loaderPatched) return;
        uint range = m.ReadU32(RangePtr);
        if (Ram(range)) m.WriteU32(range, _loaderSaved);
        _loaderPatched = false;
    }

    // prima del controllo: soglia di disattivazione allargata
    [PreHook("game", Address = 0x80041B84u)]
    public static void BeforeActivation(CpuContext c, IMemory m)
    {
        _patched = false;
        uint range = m.ReadU32(RangePtr);
        if (!Ram(range)) return;

        uint wake = m.ReadU32(range), far = m.ReadU32(range + 4u);
        if (range != _range || wake != _origWake)
        {
            _range = range;
            _origWake = wake;
            _origFar = far;
            _shown.Clear();
            _kept.Clear();
            _preloaded.Clear();
            Log($"soglie del gioco: sveglia {Math.Sqrt(wake):0}, disattivazione {Math.Sqrt(far):0}");
        }

        float f = Factor();
        if (!Enabled || f <= 1f) return;
        double extended = Math.Sqrt(_origFar) * f;
        m.WriteU32(range + 4u, (uint)Math.Min(extended * extended, uint.MaxValue));
        _patched = true;

        // precaricamento degli oggetti mai stati svegli (senza elemento fermo)
        uint thing = m.ReadU32(ThingList + ThingNext);
        for (int guard = 0; guard < 2048 && Ram(thing) && thing != ThingList; guard++)
        {
            bool sleeping = (m.ReadU32(thing + ThingFlags) & FlagAsleep) != 0;
            uint items = m.ReadU32(thing + ThingItems);
            if (sleeping && Ram(items) && !Ram(m.ReadU32(items)) && _preloaded.Add(thing))
            {
                m.WriteU8(thing + ThingWakeCounter, 1);
                Log($"precarico {thing:X8} (tipo {m.ReadU32(thing + ThingType):X8})");
            }

            thing = m.ReadU32(thing + ThingNext);
        }
    }

    static long Distance(IMemory m, uint thing, int rx, int ry, int rz)
    {
        long dx = (int)m.ReadU32(thing + ThingPos) - rx;
        long dy = (int)m.ReadU32(thing + ThingPos + 4u) - ry;
        long dz = (int)m.ReadU32(thing + ThingPos + 8u) - rz;
        uint type = m.ReadU32(thing + ThingType);
        return dx * dx + dy * dy + dz * dz - (Ram(type) ? (int)m.ReadU32(type + TypeRadius) : 0);
    }

    [PostHook("game", Address = 0x80041B84u)]
    public static void AfterActivation(CpuContext c, IMemory m)
    {
        uint range = _range;
        if (!Ram(range)) return;
        if (_patched) m.WriteU32(range + 4u, _origFar);   // il resto del gioco vede il valore originale

        long wake = _origWake;
        double extended = Math.Sqrt(_origFar) * (_patched ? Factor() : 1f);
        long limit = (long)(extended * extended);
        int rx = (int)m.ReadU32(RefPoint), ry = (int)m.ReadU32(RefPoint + 4u), rz = (int)m.ReadU32(RefPoint + 8u);

        bool summary = DiagOn && _calls++ % 50 == 0;
        _inListNow.Clear();
        int total = 0, asleep = 0, shown = 0;

        uint thing = m.ReadU32(ThingList + ThingNext);
        for (int guard = 0; guard < 2048 && Ram(thing) && thing != ThingList; guard++)
        {
            uint next = m.ReadU32(thing + ThingNext);
            total++;
            _inListNow.Add(thing);
            if (DiagOn && !_inList.Contains(thing))
                Log($"entra {thing:X8} tipo {m.ReadU32(thing + ThingType):X8} a {Dist(Distance(m, thing, rx, ry, rz))} pos {(int)m.ReadU32(thing + ThingPos)},{(int)m.ReadU32(thing + ThingPos + 4u)},{(int)m.ReadU32(thing + ThingPos + 8u)} f50 {m.ReadU32(thing + ThingFlags):X8} +70 {m.ReadU32(thing + ThingItems):X8} | rif {rx},{ry},{rz}");
            uint item = Item(m, thing);
            bool sleeping = (m.ReadU32(thing + ThingFlags) & FlagAsleep) != 0;

            bool light = (m.ReadU32(thing + ThingKind) & KindLight) != 0;
            if (light)
            {
                // fiaccole: l'elemento fermo e' senza fiamma, meglio come nell'originale
                if (item != 0 && _shown.Remove(thing))
                    m.WriteU16(item + ItemFlags, (ushort)(m.ReadU16(item + ItemFlags) | FlagHidden));
            }
            else if (item != 0 && sleeping)
            {
                asleep++;
                long dx = (int)m.ReadU32(thing + ThingPos) - rx;
                long dy = (int)m.ReadU32(thing + ThingPos + 4u) - ry;
                long dz = (int)m.ReadU32(thing + ThingPos + 8u) - rz;
                uint type = m.ReadU32(thing + ThingType);
                long d = dx * dx + dy * dy + dz * dz - (Ram(type) ? (int)m.ReadU32(type + TypeRadius) : 0);

                ushort flags = m.ReadU16(item + ItemFlags);
                bool want = _patched && d >= wake && d < limit;
                if (want)
                {
                    shown++;
                    if ((flags & FlagHidden) != 0) m.WriteU16(item + ItemFlags, (ushort)(flags & ~FlagHidden));
                    if (_shown.Add(thing)) Log($"mostro {thing:X8} a {Dist(d)}");
                }
                else if (_shown.Remove(thing))
                {
                    m.WriteU16(item + ItemFlags, (ushort)(flags | FlagHidden));
                    Log($"nascondo {thing:X8} a {Dist(d)}");
                }
            }
            else _shown.Remove(thing);   // sveglio o senza elemento fermo: lo gestisce il gioco

            thing = next;
        }

        if (DiagOn)
            foreach (var gone in _inList)
                if (!_inListNow.Contains(gone)) Log($"esce {gone:X8}");
        (_inList, _inListNow) = (_inListNow, _inList);

        _info = $"gioco: sveglia {Math.Sqrt(_origWake):0}, disattivazione {Math.Sqrt(_origFar):0} -> {extended:0} | " +
                $"oggetti {total}, addormentati {asleep}, mostrati {shown}, precaricati {_preloaded.Count}";
        if (summary) Log($"riepilogo: {_info}");
    }

    static string Dist(long d) => Math.Sqrt(Math.Max(d, 0)).ToString("0");

    static uint Item(IMemory m, uint thing)
    {
        uint items = m.ReadU32(thing + ThingItems);
        if (!Ram(items)) return 0;
        uint item = m.ReadU32(items);
        return Ram(item) ? item : 0;
    }

    static bool Ram(uint a) => (a & 0xFF000000u) == 0x80000000u && (a & 0x00FFFFFFu) < 0x00200000u;
}
